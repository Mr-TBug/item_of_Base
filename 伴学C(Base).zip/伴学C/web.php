<?php
header("Content-Type: text/html;charset=utf-8");

$code = $_POST['code'] ?? '';
$host = '127.0.0.1';
$port = 5000;
$path = '/api';

$postData = http_build_query([
    'code' => $code
]);

$socket = fsockopen($host, $port, $errno, $errstr, 10);
if (!$socket) {
    echo "连接失败：" . htmlspecialchars($errstr) . " (" . $errno . ")";
    exit;
}

$req  = "POST {$path} HTTP/1.1\r\n";
$req .= "Host: {$host}:{$port}\r\n";
$req .= "Content-Type: application/x-www-form-urlencoded\r\n";
$req .= "Content-Length: " . strlen($postData) . "\r\n";
$req .= "Connection: close\r\n\r\n";
$req .= $postData;

fwrite($socket, $req);
$resp = '';
while (!feof($socket)) {
    $chunk = fgets($socket, 4096);
    if ($chunk === false) break;
    $resp .= $chunk;
}
fclose($socket);

list($header, $body) = explode("\r\n\r\n", $resp, 2);
echo "<p>AI回答：</p><pre>" . htmlspecialchars($body) . "</pre>";
?>

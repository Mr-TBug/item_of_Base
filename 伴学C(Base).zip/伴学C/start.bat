@echo off
chcp 65001
echo ====================== 伴学C 启动器 ======================
echo 正在启动Flask后端（5000端口）...
start "" /D "%~dp0app" "app.exe"

echo 正在启动PHP前端服务（8080端口）...
start "" "php\php.exe" -S 127.0.0.1:8080 -t .

echo.
echo ✅ 启动完成！浏览器打开： http://127.0.0.1:8080/index.html
echo.
echo ⚠️ 使用前提：Ollama已启动，并且执行 ollama pull qwen2.5:7b
echo 退出方式：
echo    ① 网页点【关闭后端服务】按钮
echo    ② 直接关掉两个黑色控制台窗口
echo 按任意键关闭本启动窗口（服务后台继续运行）
pause
